#include "initialisation.h"

int initialisation() {

}