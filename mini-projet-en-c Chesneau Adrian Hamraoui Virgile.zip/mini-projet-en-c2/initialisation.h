//
// Created by Adou on 26/10/2025.
//

#ifndef INITIALISATION_H
#define INITIALISATION_H

void initialiserDonneesTest(void);


#endif //INITIALISATION_H